export class User {
    userName : string;
    userEmail : string;
    password : string;
    repassword : string;
}

export class Login {
    functionm: string;
    email : string;
    password : string;
}